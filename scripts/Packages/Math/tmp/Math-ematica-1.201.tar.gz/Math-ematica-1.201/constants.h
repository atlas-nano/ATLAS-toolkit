/*                               -*- Mode: C -*- 
 * $Basename: constants.h $
 * $Revision: 1.2 $
 * Author          : Ulrich Pfeifer
 * Created On      : Sat Dec 20 16:20:05 1997
 * Last Modified By: Ulrich Pfeifer
 * Last Modified On: Sun Dec 21 12:02:17 1997
 * Language        : C
 * Update Count    : 4
 * Status          : Unknown, Use with caution!
 * 
 * (C) Copyright 1997, Ulrich Pfeifer, all rights reserved.
 * 
 */

#ifndef CONSTANTS_H
#define CONSTANTS_H
extern double MLconstant _((char *name, int arg));
#endif /* CONSTANTS_H */
